<?php $user = Auth::user(); ?>

 
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.member', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="page-content">
    <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- START BREADCRUMB -->
        <ul class="breadcrumb">
            <li><a href="/">Home</a></li>
            <li><a href="">Set Compensation</a></li>
        </ul>
        <!-- END BREADCRUMB -->

        <!-- PAGE TITLE -->
        <div class="page-title">
            <h2><span class="fa fa-gift"></span> Set Compensations</h2>
        </div>
        <!-- END PAGE TITLE -->

        <!-- PAGE CONTENT WRAPPER -->
        <div class="page-content-wrap">



            <div class="row">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Compensations</h3>
                    </div>
                    <div class="panel-body">
                        <?php if(session('status')): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="alert alert-<?php echo e((session('status')) ? 'success' : 'danger'); ?>" role="alert">
                                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                                    <?php echo e((session('status')) ? 'You have successfully modified compensation' : 'An error occured. Please try again later or contact support if issue persists.'); ?>

                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Level</th>
                                        <th>Compensation details</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($l->name); ?></td>
                                        <td>
                                            <span class="hidden id"><?php echo e($l->id); ?></span>
                                            <span class="hidden old_reward"><?php echo e($l->rewards); ?></span>
                                            <input type="text" value="<?php echo e($l->rewards); ?>" class="form-control" />
                                        </td>
                                        <td><button class="updateBtn btn btn-primary" disabled>Set</button></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <form action="<?php echo e(route('admin.compensations')); ?>" id="comp-form" class="hidden" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="text" name="level_id" id="level_id" class="hidden"/>
                                        <input type="text" name="compensation" id="compensation" class="hidden"/>
                                    </form>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>


        </div>
        <!-- END PAGE CONTENT WRAPPER -->
    </div>
    <!-- END PAGE CONTENT -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(function(){
            $('.updateBtn').click(function(){
                var compensation = $(this).parents('tr').find('input').val();
                var id = $(this).parents('tr').find('span').text();

                if(compensation && id){
                    $('#level_id').val(id);
                    $('#compensation').val(compensation);
                    $('#comp-form').submit();
                }
                
            });

            $('.form-control').on('input', function(){
                setButton(this);
            });

            $('.form-control').on('focus', function(){
                setButton(this);
            });

            function setButton(input){
                var old_value = $(input).parent().find('span.old_reward').text();
                var new_value = $(input).val();
                var button = $(input).parents('tr').find('button');
                if(new_value != null && new_value.trim() != "" && new_value.trim() != old_value)
                    button.attr('disabled', false);
                else
                    button.attr('disabled', true);
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>