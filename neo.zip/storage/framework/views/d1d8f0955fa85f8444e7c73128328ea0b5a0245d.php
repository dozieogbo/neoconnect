<?php $user = Auth::user(); ?>

 
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.member', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="page-content">
    <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- START BREADCRUMB -->
    <ul class="breadcrumb">
        <li><a href="/">Home</a></li>
        <li><a href="">Downlines</a></li>
    </ul>
    <!-- END BREADCRUMB -->

    <!-- PAGE TITLE -->
    <div class="page-title">
        <h2><span class="fa fa-level-down"></span> My Downlines</h2>
    </div>
    <!-- END PAGE TITLE -->

    <!-- PAGE CONTENT WRAPPER -->
    <div class="page-content-wrap">



        <div class="row">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Downlines</h3>
                </div>
                <div class="panel-body">

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>id</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Phone number</th>
                                    <th>Upline</th>
                                    <th>Level</th>
                                </tr>
                            </thead>
                            
                            <tbody>
                                <?php $i = 1?>
                                <?php $__currentLoopData = $downlines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($d->user->firstname); ?></td>
                                    <td><?php echo e($d->user->surname); ?></td>
                                    <td><?php echo e($d->user->email); ?></td>
                                    <td><?php echo e($d->user->phone_no); ?></td>
                                    <td><?php echo e($d->parent->user->firstname); ?></td>
                                    <td><?php echo e($d->level->number); ?></td>
                                </tr>
                                <?php $i++ ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            
                        </table>
                        <?php echo e($downlines->links()); ?>

                    </div>
                </div>
            </div>

        </div>


    </div>
    <!-- END PAGE CONTENT WRAPPER -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>