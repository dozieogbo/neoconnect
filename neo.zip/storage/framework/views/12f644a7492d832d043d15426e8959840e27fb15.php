<?php $user = Auth::user(); ?>

 
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.member', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="page-content">
    <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- START BREADCRUMB -->
            <ul class="breadcrumb">
                <li><a href="/">Home</a></li>
                <li><a href="">Compensations</a></li>
            </ul>
            <!-- END BREADCRUMB -->

            <!-- PAGE TITLE -->
            <div class="page-title">
                <h2><span class="fa fa-gift"></span> My Compensations</h2>
            </div>
            <!-- END PAGE TITLE -->

            <!-- PAGE CONTENT WRAPPER -->
            <div class="page-content-wrap">
                <div class="row">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">Compensations</h3>
                        </div>
                        <div class="panel-body">

                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Level</th>
                                            <th>Name</th>
                                            <th>Compensation details</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $i = 1?>
                                    <?php $__currentLoopData = $compensations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                        <td><?php echo e($c->level->number); ?></td>
                                            <td><?php echo e($c->level->name); ?></td>

                                            <td><?php echo e($c->level->rewards); ?></td>
                                            <?php if($c->has_received): ?>
                                            <td><button>Claim</button></td>
                                            <?php else: ?>
                                            <td>Claimed</td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php $i++?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php echo e($compensations->links()); ?>

                            </div>
                        </div>
                    </div>

                </div>


            </div>
            <!-- END PAGE CONTENT WRAPPER -->
        </div>
        <!-- END PAGE CONTENT -->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>