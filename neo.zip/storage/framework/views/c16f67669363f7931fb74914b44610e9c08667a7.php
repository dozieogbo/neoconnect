<?php $__env->startSection('content'); ?>
    <!-- START PAGE SIDEBAR -->
    <div class="page-sidebar">
        <!-- START X-NAVIGATION -->
        <ul class="x-navigation">
            <li class="xn-logo">
                <a href="index.html">Neoconnect</a>
                <a href="#" class="x-navigation-control"></a>
            </li>
            <li class="xn-profile">
                <a href="#" class="profile-mini">
                    <img src="<?php echo e(URL::to('assets/images/users/avatar.jpg')); ?>" alt="<?php echo e($user->firstname); ?>" />
                </a>
                <div class="profile">
                    <div class="profile-image">
                        <img src="<?php echo e(URL::to('assets/images/users/avatar.jpg')); ?>" alt="<?php echo e($user->firstname); ?>" />
                    </div>
                    <div class="profile-data">
                        <div class="profile-data-name"><?php echo e($user->firstname); ?> <?php echo e($user->surname); ?></div>
                        <div class="profile-data-title"><?php echo e($user->member->level->name); ?></div>
                        <!-- Put the persons level Here -->
                    </div>
                    <div class="profile-controls">
                        <a href="pages-profile.html" class="profile-control-left"><span class="fa fa-info"></span></a>
                        <!--Links to about person Page -->
                        <a href="pages-messages.html" class="profile-control-right"><span class="fa fa-registered"></span></a>
                        <!--Links to about Register Person By Person page Page -->
                    </div>
                </div>
            </li>
            <li class="xn-title">Navigation</li>

            <li class="xn-openable">
                <a href="#"><span class="fa fa-dashboard"></span> <span class="xn-text">Profile</span></a>
                <ul>
                    <li><a href="pages-gallery.html"><span class="fa fa-info"></span> My Info</a></li>
                    <li><a href="pages-invoice.html"><span class="fa fa-edit"></span> Edit Profile</a></li>
                </ul>
            </li>
            <li class="xn-openable">
                <a href="#"><span class="fa fa-users"></span> <span class="xn-text">Downlines</span></a>
                <ul>
                    <li><a href="pages-gallery.html"><span class="fa fa-user"></span> My Downlines</a></li>
                    <li><a href="pages-invoice.html"><span class="fa fa-registered"></span> New User</a></li>
                </ul>
            </li>

        </ul>
        <!-- END X-NAVIGATION -->
    </div>
    <!-- END PAGE SIDEBAR -->

    <?php echo $__env->yieldContent('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>