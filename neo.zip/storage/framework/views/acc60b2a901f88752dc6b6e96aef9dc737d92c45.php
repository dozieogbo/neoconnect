<?php $user = Auth::user(); ?>

 
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="page-content">
    <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- START BREADCRUMB -->
        <ul class="breadcrumb">
            <li><a href="/">Home</a></li>
            <li><a href="<?php echo e(route('admin.announcements')); ?>">Announcements</a></li>
            <li><a href="">New</a></li>
        </ul>
        <!-- END BREADCRUMB -->

        <!-- PAGE TITLE -->
        <div class="page-title">
            <h2><span class="fa fa-user"></span> Announcements</h2>
        </div>
        <!-- END PAGE TITLE -->

        <!-- PAGE CONTENT WRAPPER -->
        <div class="page-content-wrap">



            <div class="row">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <?php if(isset($status)): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="alert alert-success" role="alert">
                                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                                    Announcement created successfully
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('admin.announcements.create')); ?>" class="form-horizontal" method="post">
                        <?php echo e(csrf_field()); ?>

                            <div class="form-group<?php echo e($errors->has('content') ? ' has-error' : ''); ?>">
                                <label for="content" class="control-label-lg">Content</label>
                                <textarea name="content" id="content" rows="30" cols="1" required class="form-control" placeholder="Write your announcement content here" value="<?php echo e(old('content')); ?>">
                                </textarea>
                                <?php if($errors->has('content')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('content')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <button type="submit" class="btn btn-lg btn-primary pull-right">Save</button>
                        </form>
                    </div>
                </div>

            </div>


        </div>
        <!-- END PAGE CONTENT WRAPPER -->
    </div>
    <!-- END PAGE CONTENT -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>