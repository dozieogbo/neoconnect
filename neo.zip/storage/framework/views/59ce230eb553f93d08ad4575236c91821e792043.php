<?php $user = Auth::user(); ?>

 
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.member', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="page-content">
    <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- START BREADCRUMB -->
            <ul class="breadcrumb">
                <li><a href="/">Home</a></li>
                <li><a href="<?php echo e(route('user.downlines')); ?>">Downlines</a></li>
                <li><a href="">New</a></li>
            </ul>
            <!-- END BREADCRUMB -->

            <!-- PAGE TITLE -->
            <div class="page-title">
                <h2><span class="fa fa-users"></span>REGISTER NEW DOWNLINE</h2>
            </div>
            <!-- END PAGE TITLE -->

            <!-- PAGE CONTENT WRAPPER -->
            <div class="page-content-wrap">

                <div class="row">

                    <div class="col-md-offset-3 col-md-6 col-sm-8 col-xs-7">

                    <?php if(isset($status)): ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="alert alert-<?php echo e(($status == 'success') ? 'success' : 'danger'); ?>" role="alert">
                                <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                                <?php echo e(($status == 'success') ? 'Your downline has been added successfully.' : 'Sorry. An error occured. Please, try again later or contact support.'); ?>

                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                        <form action="<?php echo e(route('user.downline.create')); ?>" class="form-horizontal" method="post">
                        <?php echo e(csrf_field()); ?>

                            <div class="panel panel-default">
                                <div class="panel-body">
                                    <h3><span class="fa fa-pencil"></span> Person Profile</h3>
                                    <p>This is the details of the person you want to register as your downline. If your immediate downlo=ines are complete, the person will spill over to one of your downlines, still growing your network</p>
                                </div>
                                <div class="panel-body form-group-separated">
                                    <div class="form-group<?php echo e($errors->has('firstname') ? ' has-error' : ''); ?>">
                                        <label class="col-md-3 col-xs-5 control-label">First Name</label>
                                        <div class="col-md-9 col-xs-7">
                                            <input type="text" class="form-control" name="firstname" value="<?php echo e(old('firstname')); ?>" required/>
                                            <?php if($errors->has('firstname')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('firstname')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('lastname') ? ' has-error' : ''); ?>">
                                        <label class="col-md-3 col-xs-5 control-label">Surname</label>
                                        <div class="col-md-9 col-xs-7">
                                            <input type="text" class="form-control" name="lastname" value="<?php echo e(old('lastname')); ?>" required/>
                                            <?php if($errors->has('lastname')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('lastname')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                        <label class="col-md-3 col-xs-5 control-label">Email</label>
                                        <div class="col-md-9 col-xs-7">
                                            <input type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required/>

                                            <?php if($errors->has('email')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                        <label class="col-md-3 col-xs-5 control-label">Password</label>
                                        <div class="col-md-9 col-xs-7">
                                            <input type="password" class="form-control" placeholder="Password" name="password" />
                                            <?php if($errors->has('password')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-md-3 col-xs-5 control-label">Re-Password</label>
                                        <div class="col-md-9 col-xs-7">
                                            <input type="password" class="form-control" name="password_confirmation"/>
                                        </div>
                                    </div>

                                    <div class="form-group<?php echo e($errors->has('phone_no') ? ' has-error' : ''); ?>">
                                        <label class="col-md-3 col-xs-5 control-label">Phone number</label>
                                        <div class="col-md-9 col-xs-7">
                                            <input type="text" class="form-control" name="phone_no" value="<?php echo e(old('phone_no')); ?>" required />
                                            <?php if($errors->has('phone_no')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('phone_no')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-md-3 col-xs-5 control-label">City</label>
                                        <div class="col-md-9 col-xs-7">
                                            <input type="text" class="form-control" />
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-md-3 col-xs-5 control-label">State</label>
                                        <div class="col-md-9 col-xs-7">
                                            <input type="text" class="form-control" />
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-md-3 col-xs-5 control-label">Country</label>
                                        <div class="col-md-9 col-xs-7">
                                            <select class="form-control select" data-live-search="true">
                                                <option>Country</option>
                                                <option>Nigeria</option>
                                                <option>Ghana</option>
                                                <option>South Africa</option>
                                                <option>USA</option>
                                                <option>UK</option>                
                                            </select>
                                        </div>
                                    </div>



                                    <div class="form-group">
                                        <div class="col-md-12 col-xs-5">
                                            <button type="submit" class="btn btn-primary btn-rounded pull-right">Save</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
            <!-- END PAGE CONTENT WRAPPER -->
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>