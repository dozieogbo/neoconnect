<?php $user = Auth::user(); ?>

 
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="page-content">
    <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- START BREADCRUMB -->
        <ul class="breadcrumb">
            <li><a href="/">Home</a></li>
            <li><a href="">Users</a></li>
        </ul>
        <!-- END BREADCRUMB -->

        <!-- PAGE TITLE -->
        <div class="page-title">
            <h2><span class="fa fa-user"></span> Users</h2>
        </div>
        <!-- END PAGE TITLE -->

        <!-- PAGE CONTENT WRAPPER -->
        <div class="page-content-wrap">

            <div class="row">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Please Enter search parameters</h3>
                    </div>
                    <div class="panel-body">

                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Country</th>
                                        <th>State</th>
                                        <th>Level</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                            <td>
                                            <select class="form-control select" data-live-search="true" name="country" id="country">
                                                <option value="">All</option>
                                                <option>Nigeria</option>
                                                <option>Ghana</option>
                                                <option>South Africa</option>
                                                <option>USA</option>
                                            </select>
                                        </td>
                                        <td>
                                            <select class="form-control select" data-live-search="true" name="state" id="state" value="">
                                                <option value="">All</option>
                                                <option>Nigeria</option>
                                                <option>Ghana</option>
                                                <option>South Africa</option>
                                                <option>USA</option>
                                            </select>
                                        </td>
                                        <td>
                                            <select class="form-control select" data-live-search="true" name="level" id="level" value="">
                                                <option value="">All Levels</option>
                                                <option value="Neo">Neo</option>
                                                <option>Neo-Plus</option>
                                                <option>Bronze</option>
                                                <option>Silver</option>
                                                <option>Jasper</option>
                                            </select>
                                        </td>

                                        <td><button type="button" id="search-btn">Search</button></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <?php if(session('user_status')): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="alert alert-<?php echo e((session('user_status')) ? 'success' : 'danger'); ?>" role="alert">
                                    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                                    User was successfully <?php echo e(session('is_active') ? 'activated' : 'deactivated'); ?>.
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Email</th>
                                        <th>Phone number</th>
                                        <th>Level</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($m->user->firstname); ?></td>
                                        <td><?php echo e($m->user->surname); ?></td>
                                        <td><?php echo e($m->user->email); ?></td>
                                        <td><?php echo e($m->user->phone_no); ?></td>
                                        <td><?php echo e($m->level->name); ?></td>
                                        <td>
                                        <a class="btn btn-xs btn-primary btn-rounded" href="<?php echo e(route('admin.user', ['id' => $m->user_id])); ?>">View</a>
                                        <?php if($m->user->is_active): ?>
                                        <a class="updateBtn btn btn-xs btn-danger btn-rounded" href="<?php echo e(route('admin.user.status', ['id' => $m->user_id, 'status' => 'deactivate'])); ?>">Block</a>
                                        <?php else: ?>
                                        <a class="updateBtn btn btn-xs btn-success btn-rounded" href="<?php echo e(route('admin.user.status', ['id' => $m->user_id, 'status' => 'activate'])); ?>">Unblock</a>
                                        <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo e($members->appends($query)->render()); ?>

                        </div>
                    </div>
                </div>

            </div>


        </div>
        <!-- END PAGE CONTENT WRAPPER -->
    </div>
    <!-- END PAGE CONTENT -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(function(){
            var state = $('#state');
            var country = $('#state');
            var level = $('#level');

            state.val('<?php echo e(array_key_exists('state', $query) ? $query['state'] : ''); ?>');
            country.val('<?php echo e(array_key_exists('country', $query) ? $query['country'] : ''); ?>');
            level.val('<?php echo e(array_key_exists('level', $query) ? $query['level'] : ''); ?>');

            $('#search-btn').click(function(){
                console.log("Clicked")
                var url = '<?php echo e(route('admin.users')); ?>';
                var params = {};

                if(state.val() != '' || country.val() != '' || level.val() != ''){
                    url = url + '?';
                    if(state.val() != '')
                        params.state = state.val();
                    if(country.val() != '')
                        params.country = country.val();
                    if(level.val() != '')
                        params.level = level.val();
                    url = url + $.param(params);
                }

                location.href = url;
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>