<?php $user = Auth::user(); $upline = $user->member->parent->user; ?>

 
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.member', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="page-content">
    <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- START BREADCRUMB -->
        <ul class="breadcrumb">
            <li><a href="/">Home</a></li>
            <li><a href="">Upline</a></li>
        </ul>
        <!-- END BREADCRUMB -->

        <!-- PAGE TITLE -->
        <div class="page-title">
            <h2><span class="fa fa-level-up"></span> My Upline</h2>
        </div>
        <!-- END PAGE TITLE -->

        <!-- PAGE CONTENT WRAPPER -->
        <div class="page-content-wrap">



            <div class="row">
                <div class="col-md-offset-3 col-md-6">

                    <form action="#" class="form-horizontal">
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <h3><span class="fa fa-user text-center"></span> <?php echo e($upline->firstname); ?> <?php echo e($upline->surname); ?></h3>

                                <div class="text-center" id="user_image">
                                    <img src="<?php echo e(URL::to($upline->pic_url)); ?>" class="img-thumbnail" />
                                </div>
                            </div>
                            <div class="panel-body form-group-separated">


                                <div class="form-group">
                                    <label class="col-md-3 col-xs-5 control-label">NEO ID</label>
                                    <div class="col-md-9 col-xs-7">
                                        <input type="text" value="<?php echo e($upline->member->member_id); ?>" class="form-control" disabled/>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-md-3 col-xs-5 control-label">Email</label>
                                    <div class="col-md-9 col-xs-7">
                                        <input type="text" value="<?php echo e($upline->email); ?>" class="form-control" disabled/>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-md-3 col-xs-5 control-label">Phone Number</label>
                                    <div class="col-md-9 col-xs-7">
                                        <input type="text" value="<?php echo e($upline->phone_no); ?>" class="form-control" disabled/>
                                    </div>
                                </div>



                            </div>
                        </div>
                    </form>

                </div>

            </div>


        </div>
        <!-- END PAGE CONTENT WRAPPER -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>