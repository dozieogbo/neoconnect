<?php $user = Auth::user(); ?>

 
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="page-content">
    <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- START BREADCRUMB -->
        <ul class="breadcrumb">
            <li><a href="/">Admin</a></li>

            <li class="active">User Details</li>
        </ul>
        <!-- END BREADCRUMB -->

        <!-- PAGE TITLE -->
        <div class="page-title">
            <h2><span class="fa fa-users"></span> User Details</h2>
        </div>
        <!-- END PAGE TITLE -->

        <!-- PAGE CONTENT WRAPPER -->
        <div class="page-content-wrap">



            <div class="row">
                <div class="col-md-offset-3 col-md-6">
                    <?php if(session('user_status')): ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="alert alert-success" role="alert">
                                <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                                You have successfully <?php echo e($member->is_active ? 'activated' : 'deactivated'); ?> this user.
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <form action="#" class="form-horizontal">
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <h3><span class="fa fa-user text-center"></span><?php echo e($member->firstname); ?> <?php echo e($member->surname); ?></h3>

                                <div class="text-center" id="user_image">
                                    <img src="<?php echo e(empty($member->pic_url) ? URL::to('assets/images/users/no-image.jpg') : URL::to($member->pic_url)); ?>" class="img-thumbnail" />
                                </div>
                            </div>
                            <div class="panel-body form-group-separated">


                                <div class="form-group">
                                    <label class="col-md-3 col-xs-5 control-label">NeoID</label>
                                    <div class="col-md-9 col-xs-7">
                                        <input type="text" value="<?php echo e($member->member->member_id); ?>" class="form-control" disabled/>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-md-3 col-xs-5 control-label">Email</label>
                                    <div class="col-md-9 col-xs-7">
                                        <input type="text" value="<?php echo e($member->email); ?>" class="form-control" disabled/>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-md-3 col-xs-5 control-label">Phone Number</label>
                                    <div class="col-md-9 col-xs-7">
                                        <input type="text" value="<?php echo e($member->phone_no); ?>" class="form-control" disabled/>
                                    </div>
                                </div>
                                <?php if($member->is_active): ?>
                                <div class="form-group">
                                    <div class="col-md-12 col-xs-12">
                                        <a href="<?php echo e(route('admin.user.status', ['id' => $member->id, 'status' => 'deactivate'])); ?>" class="btn btn-danger btn-block btn-rounded">Block User</a>
                                    </div>
                                </div>
                                <?php else: ?>
                                <div class="form-group">
                                    <div class="col-md-12 col-xs-12">
                                        <a href="<?php echo e(route('admin.user.status', ['id' => $member->id, 'status' => 'activate'])); ?>" class="btn btn-success btn-block btn-rounded">Unblock User</a>
                                    </div>
                                </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </form>
                </div>

            </div>


        </div>
        <!-- END PAGE CONTENT WRAPPER -->
    </div>
    <!-- END PAGE CONTENT -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>